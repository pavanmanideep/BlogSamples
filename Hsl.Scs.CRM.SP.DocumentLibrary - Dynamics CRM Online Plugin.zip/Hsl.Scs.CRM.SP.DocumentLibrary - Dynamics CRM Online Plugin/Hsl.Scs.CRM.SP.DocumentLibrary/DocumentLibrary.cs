﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Hsl.Scs.CRM.SP.DocumentLibrary
{
    public class DocumentLibrary : IPlugin
    {
        private XmlDocument _pluginConfiguration;

        private IOrganizationService _service;
        public DocumentLibrary(string unsecureConfig, string secureConfig)
        {
            if (string.IsNullOrEmpty(unsecureConfig))
            {
                throw new InvalidPluginExecutionException("Unsecure configuration missing.");
            }
            _pluginConfiguration = new XmlDocument();
            _pluginConfiguration.LoadXml(unsecureConfig);
        }
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory _serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                _service = (IOrganizationService)_serviceFactory.CreateOrganizationService(context.UserId);
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity ent = (Entity)context.InputParameters["Target"];
                    string folderkey = GetConfigDataString(_pluginConfiguration, ent.LogicalName);
                    if (String.IsNullOrEmpty(folderkey))
                    {
                        throw new InvalidPluginExecutionException("Not able to find  config for the enttiy" + ent.LogicalName);
                    }
                    if (ent.Contains(folderkey))
                    {
                        string stSiteDomain = string.Empty, tenantID = string.Empty, resourceID = string.Empty, stClientID = string.Empty,
                            stClientSecret = string.Empty, siteurl = string.Empty, stGetAccessTokenUrl = string.Empty,stGetTenantDetailsUrl = string.Empty; ;
                        resourceID = GetConfigDataString(_pluginConfiguration, "resourceID");

                        stClientID = GetConfigDataString(_pluginConfiguration, "stClientID");

                        stClientSecret = GetConfigDataString(_pluginConfiguration, "stClientSecret");

                        stSiteDomain = GetConfigDataString(_pluginConfiguration, "stSiteDomain");

                        siteurl = GetConfigDataString(_pluginConfiguration, "siteurl");

                        stGetTenantDetailsUrl = GetConfigDataString(_pluginConfiguration, "stGetTenantDetailsUrl");
                        stGetAccessTokenUrl = GetConfigDataString(_pluginConfiguration, "stGetAccessTokenUrl");
                        tenantID = GetTenant(stGetTenantDetailsUrl);

                        string token = GetAuthorisationToken(stGetAccessTokenUrl, stSiteDomain, tenantID, resourceID, stClientID, stClientSecret);
                        CreateFolder(siteurl, token, ent.LogicalName, ent[folderkey].ToString(),ent.Id);                        
                        CreateDocumentLocation(ent.LogicalName, ent[folderkey].ToString() + " Document Location", ent[folderkey].ToString(), ent.Id);
                    }
                    else
                    {
                        throw new InvalidPluginExecutionException(folderkey + "is a mandatory field");
                    }
                }
            }
            catch (Exception ex)
            {
                createlog(_service, "Error occured" + ex.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public string GetAuthorisationToken(string stGetAccessTokenUrl, string stSiteDomain, string tenantID, string resourceID, string stClientID, string stClientSecret)
        {

            string accessToken = string.Empty;
            stGetAccessTokenUrl = string.Format(stGetAccessTokenUrl, tenantID);

            WebRequest request = WebRequest.Create(stGetAccessTokenUrl);

            request.ContentType = "application/x-www-form-urlencoded";
            request.Method = "POST";

            string postData = "grant_type = client_credentials" +
                     "&client_id =" + WebUtility.UrlEncode(stClientID + "@" + tenantID) +
                     "&client_secret =" + WebUtility.UrlEncode(stClientSecret) +
                     "&resource =" + WebUtility.UrlEncode(resourceID + "/" + stSiteDomain + "@" + tenantID);

            byte[] byteArray = Encoding.UTF8.GetBytes(postData);
            // Set the ContentType property of the WebRequest. 
            request.ContentType = "application/x-www-form-urlencoded";
            // Set the ContentLength property of the WebRequest. 
            request.ContentLength = byteArray.Length;
            // Get the request stream. 
            Stream dataStream = request.GetRequestStream();
            // Write the data to the request stream. 
            dataStream.Write(byteArray, 0, byteArray.Length);
            // Close the Stream object. 
            dataStream.Close();

            try
            {
                using (WebResponse response = request.GetResponse())
                {
                    dataStream = response.GetResponseStream();
                    // Open the stream using a StreamReader for easy access. 
                    StreamReader reader = new StreamReader(dataStream);
                    // Read the content. 
                    string responseFromServer = reader.ReadToEnd();
                    // Clean up the streams. 
                    reader.Close();
                    dataStream.Close();
                    //Get accesss token
                    accessToken = "access_token\":\"";
                    int clientIndex = responseFromServer.IndexOf(accessToken, StringComparison.Ordinal);
                    int accessTokenIndex = clientIndex + accessToken.Length;
                    accessToken = responseFromServer.Substring(accessTokenIndex, (responseFromServer.Length - accessTokenIndex - 2));

                    return accessToken;

                }
            }
            catch (WebException wex)
            {
                HttpWebResponse httpResponse = wex.Response as HttpWebResponse;
                createlog(_service, "Error occured" + wex.ToString());
                throw new InvalidPluginExecutionException("Exception occured while retrieving Access Token" + wex.ToString());

            }

        }

        public static string GetConfigDataString(XmlDocument doc, string label)
        {
            return GetValueNode(doc, label);
        }
        private static string GetValueNode(XmlDocument doc, string key)
        {
            XmlNode node = doc.SelectSingleNode(String.Format("Settings/setting[@name='{0}']", key));
            if (node != null)
            {
                return node.SelectSingleNode("value").InnerText;
            }
            return string.Empty;
        }

        public string GetTenant(string stGetTenantDetailsUrl)
        {
            WebRequest myWebRequest;
            string tenantID = string.Empty;
            string resourceID = string.Empty;
            string accessToken = string.Empty;

            myWebRequest = WebRequest.Create(stGetTenantDetailsUrl);
            myWebRequest.Method = "GET";
            myWebRequest.Headers.Add("Authorization", "Bearer");
            WebResponse myWebResponse = null; ;
            try
            {
                myWebResponse = myWebRequest.GetResponse();
                return tenantID;
            }
            catch (System.Net.WebException ex)
            {
                //get the Web exception and read the headers               

                string[] headerAuthenticateValue = ex.Response.Headers.GetValues("WWW-Authenticate");
                if (headerAuthenticateValue != null)
                {

                    foreach (string stHeader in headerAuthenticateValue)
                    {
                        string[] stArrHeaders = stHeader.Split(',');
                        //loop all the key value pair of WWW-Authenticate 
                        foreach (string stValues in stArrHeaders)
                        {

                            if (stValues.StartsWith("Bearer realm="))
                            {
                                tenantID = stValues.Substring(14);
                                tenantID = tenantID.Substring(0, tenantID.Length - 1);
                            }
                            if (stValues.StartsWith("client_id="))
                            {
                                //this value is consider as resourceid which is required for getting the access token 
                                resourceID = stValues.Substring(11);
                                resourceID = resourceID.Substring(0, resourceID.Length - 1);
                            }
                        }

                    }

                }

                return tenantID;
            }
        }


        #region Create Log
        public void createlog(IOrganizationService service, string message)
        {
            try
            {
                Entity _annotation = new Entity("annotation");
                _annotation.Attributes["mimetype"] = @"text/plain";
                _annotation.Attributes["notetext"] = message;
                service.Create(_annotation);
            }
            catch { }
        }
        #endregion
        public void CreateFolder(string sharePointSite, string token, string library, string folder,Guid entityID)
        {                    
            
            if (library == "contact")//Changing document location after NRIC Masking change
            {
                Entity contact = _service.Retrieve("contact", entityID, new ColumnSet("suffix"));//Populate knownas beside NRIC for contact's document name            
                string knownas = contact.GetAttributeValue<string>("suffix");
                knownas = knownas.Replace("/", "").Replace("&","");//replaced explicity as WebUtility.UrlEncode doesn't handle                
                folder = folder + "_" + WebUtility.UrlEncode(knownas);                
            }
            string result = string.Empty;
            StringBuilder sb = new StringBuilder();
            sb.Append(sharePointSite);
            sb.Append("_api/web/GetFolderByServerRelativePath(decodedUrl='");
            sb.Append(library);
            sb.Append("')/Folders");
            Uri uri = new Uri(sb.ToString().Replace("{", "").Replace("}", ""));            
            HttpWebRequest wreq = (HttpWebRequest)WebRequest.Create(uri);
            wreq.Headers.Add("Authorization", "Bearer " + token);
            wreq.Method = "POST";
            wreq.ContentType = "application/json";
            string postData = "{'ServerRelativeUrl':'folder'}";
            postData = postData.Replace("folder", folder);            
            byte[] byteArray = Encoding.UTF8.GetBytes(postData);
            wreq.ContentLength = postData.Length;
            Stream dataStream = wreq.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            dataStream.Close();
            WebResponse wresp = null;
            try
            {
                wresp = wreq.GetResponse();
                using (wresp = wreq.GetResponse())
                {
                    dataStream = wresp.GetResponseStream();
                    StreamReader reader = new StreamReader(dataStream);
                    string responseFromServer = reader.ReadToEnd();
                    reader.Close();
                }
            }
            catch (WebException wex)
            {
                HttpWebResponse httpResponse = wex.Response as HttpWebResponse;
                createlog(_service, "Error occured" + wex.ToString());
                throw new InvalidPluginExecutionException("Exception occured while creating record" + wex.ToString());
            }

            
        }
        public Guid CreateDocumentLocation(string logicalname, string name, string relativeurl, Guid recordid)
        {
            try
            {
               
                if (logicalname == "contact")//Changing document location after NRIC Masking change
                {
                    Entity contact = _service.Retrieve("contact", recordid, new ColumnSet("suffix"));//Populate knownas beside NRIC for contact's document name
                    string knownas = contact.GetAttributeValue<string>("suffix");
                    knownas = knownas.Replace("/", "").Replace("&","");//replaced explicity as WebUtility.UrlEncode doesn't handle
                    Entity document = new Entity("sharepointdocumentlocation");
                    document["name"] = name;                    
                    Guid id = GetParentDocumentLocation(logicalname);
                    document["parentsiteorlocation"] = new EntityReference("sharepointdocumentlocation", id);
                    document["regardingobjectid"] = new EntityReference(logicalname, recordid);
                    document["relativeurl"] = relativeurl + "_" + WebUtility.UrlEncode(knownas);                    
                    return _service.Create(document);
                }
                else
                {
                    Entity document = new Entity("sharepointdocumentlocation");
                    document["name"] = name;
                    Guid id = GetParentDocumentLocation(logicalname);
                    document["parentsiteorlocation"] = new EntityReference("sharepointdocumentlocation", id);
                    document["regardingobjectid"] = new EntityReference(logicalname, recordid);
                    document["relativeurl"] = relativeurl;                    
                    return _service.Create(document);
                }

            }
            catch (Exception ex)
            {
                createlog(_service, "Error occured" + ex.ToString());
                throw ex;
            }
        }


        public Guid GetParentDocumentLocation(string logicalname)
        {
            string fetchxml = string.Format(Queries.RetrieveDocumentLocation, logicalname);
            EntityCollection documentlocation = _service.RetrieveMultiple(new FetchExpression(fetchxml));
            if (documentlocation.Entities.Count == 0)
            {
                EntityCollection retrieveSharepointSite = _service.RetrieveMultiple(new FetchExpression(Queries.RetrieveSharepointSite));
                if (retrieveSharepointSite.Entities.Count == 0)
                {
                    throw new InvalidPluginExecutionException("Sharepoint Site is not configured");
                }
                else
                {
                    Entity document = new Entity("sharepointdocumentlocation");
                    document["name"] = logicalname + "Parent Site Collection";
                    document["parentsiteorlocation"] = new EntityReference("sharepointsite", retrieveSharepointSite.Entities[0].Id);
                    document["relativeurl"] = logicalname;
                    return _service.Create(document);
                }
            }
            else
            {
                return documentlocation.Entities[0].Id;
            }
        }
    }
}
